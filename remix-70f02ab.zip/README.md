# Automatic build
Built website from `70f02ab`. See https://github.com/ethereum/browser-solidity/ for details.
To use an offline copy, download `remix-70f02ab.zip`.
